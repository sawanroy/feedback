<!doctype html>
<head>
    <style type="" >

body {
 margin: 20px;background-image: url(c.jpg);
}
form {
display: table;
padding: 10px;
border: thin double blue; background: lightblue; 
}
form textarea { width: 1000%;
height: 300px; }
div.tableRow { display: block;
}
div.tableRow p { display: table-cell; vertical-align: top; padding: 10px;
}
div.tableRow p:first-child { text-align: center;
}
p.heading { font-weight: bold;
}
marquee{
    font-size: 300%;
    color: burlywood;
}
h2{
    color: purple;
    font-size: 300%;
    }
div{
    font-size: 200%;
    table-layout:inherit ;
}

</style>
<meta charset='utf-8'>
<title>User's Registration </title>
  
</head>

<body>
      <marquee behavior="alternate" direction="up" width="100%"><marquee directio <marquee behavior="alternate" direction="up" width="100%"n="right">Feedback System </marquee></marquee>

<form action="" method="post">
    <h2>REGISTER</h2>
<div class="tableRow">
USER NAME :<br> <input type="text" name="USR_NAME" value=""><br>
ENROLL NUMBER :<br> <input type="integer" name="ENROLL_NO" value=""><br>
SEMESTER : <br><input type="integer" name="Semester" value= "" ><br>
BRANCH:<br> <input type="text" name="BRANCH" value=""><br>
<big><input type= "submit" value="LOGIN"></big>
</div>
</form>
</body>
</html>