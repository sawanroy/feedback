<?php 
class Login_controller extends CI_controller{

     public function index()
     {

     	 $this->load->library('form_validation');
	    $this->form_validation->set_rules(
        'username', 'username',
        'required|min_length[5]|max_length[12]'
);
$this->form_validation->set_rules('password', 'password', 'required');
	    if ($this->form_validation->run() == FALSE)
                {
                       	$this->load->view('login2.php');
					
					
                }
                else
                {
					   $username=$this->input->post('username');
					   $password=$this->input->post('password');
					  $this->load->model('login_model');
					  $login_id=$this->login_model->index($username, $password);
					 if( $login_id )
					 	
					 {	$this->load->library('session');
					    $this->session->set_userdata('user_id',$login_id);
					     return redirect('main_controller/panel_user');
					    
					       
					 }
					 else
					 {
					 	$this->session->set_flashdata('login_failed','invalid username & password');
				         return redirect('main_controller/login');
					 }
				
                }

     }

     public function login_logout()
	{
        $this->session->unset_userdata('user_id');
        return redirect('main_controller/login');

	}

     }


?>